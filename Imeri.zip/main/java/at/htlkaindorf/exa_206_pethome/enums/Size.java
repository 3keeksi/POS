package at.htlkaindorf.exa_206_pethome.enums;

public enum Size {
    SMALL,
    MEDIUM,
    LARGE,
    NONE
}
