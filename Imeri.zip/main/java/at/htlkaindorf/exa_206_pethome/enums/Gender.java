package at.htlkaindorf.exa_206_pethome.enums;

public enum Gender {
    MALE,
    FEMALE
}
