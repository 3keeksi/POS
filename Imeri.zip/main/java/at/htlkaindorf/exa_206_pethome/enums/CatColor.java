package at.htlkaindorf.exa_206_pethome.enums;

public enum CatColor {
    BLACK,
    WHITE,
    CREAM,
    RED,
    CINNAMON,
    FAWN,
    CHOCOLATE,
    APRICOT,
    AMBER
}
