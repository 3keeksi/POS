package at.htlkaindorf.exa_202_contactsapp.bl;

import at.htlkaindorf.exa_202_contactsapp.MainActivity;
import at.htlkaindorf.exa_202_contactsapp.beans.Contact;

public class Utils {
    public static Contact currentContact = null;
    public static int currentIndex = 0;
    public static MainActivity main = null;
}
