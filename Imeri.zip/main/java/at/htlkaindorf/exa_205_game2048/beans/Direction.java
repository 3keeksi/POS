package at.htlkaindorf.exa_205_game2048.beans;

public enum Direction {
    UP,
    RIGHT,
    DOWN,
    LEFT,
    NONE
}
