SELECT * FROM public.mitarbeiter
ORDER BY pers_nr