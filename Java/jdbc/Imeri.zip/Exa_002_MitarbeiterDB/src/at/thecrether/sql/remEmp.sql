-- remove a employee
DELETE FROM mitarbeiter
WHERE pers_nr = ?;