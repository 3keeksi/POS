-- insert a employee to the table
INSERT INTO mitarbeiter (PERS_NR, NAME, VORNAME, GEB_DATUM, GEHALT, ABT_NR, GESCHLECHT) VALUES
(?, ?, ?, ?, ?, ?, ?);