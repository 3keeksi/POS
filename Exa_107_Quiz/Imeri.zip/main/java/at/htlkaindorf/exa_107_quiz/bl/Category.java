package at.htlkaindorf.exa_107_quiz.bl;

public enum Category {
    sport,
    pc_components
}
